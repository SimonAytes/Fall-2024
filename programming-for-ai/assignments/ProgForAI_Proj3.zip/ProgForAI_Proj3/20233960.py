import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
from torchvision.models import resnet50, ResNet50_Weights
from transformers import GPT2Tokenizer, GPT2LMHeadModel, AdamW, get_linear_schedule_with_warmup
import numpy as np
import random
import os
import json
from PIL import Image
import argparse

# Constants
CIFAR_BATCH_SIZE = 128
LM_BATCH_SIZE = 32
VL_BATCH_SIZE = 16
MAX_LENGTH = 128
HIDDEN_SIZE = 768
NUM_EPOCHS = 3
IMG_PATCH = '<img>'
NUM_IMG_TOKEN = 32
VLM_MAX_LENGTH = 32
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def set_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(0)

# Data Preprocessing (No Changes Allowed)
def transform_fn(is_train):
    if is_train:
        return transforms.Compose([
            transforms.RandomHorizontalFlip(),
            transforms.RandomCrop(32, padding=4),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    else:
        return transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

class LLaVADataset(Dataset):
    def __init__(self, json_file, img_path, tokenizer, is_train):
        super().__init__()
        self.transform = transform_fn(is_train)
        self.json_file = json_file
        self.tokenizer = tokenizer
        self.img_path = img_path
        self.ignore_idx = -100
        self.begin_signal = tokenizer.bos_token
        self.end_signal = tokenizer.eos_token

        with open(self.json_file) as file:
            data = json.load(file)

        self.data = data[:1000] if is_train else data[1000:]

    def preprocess(self, conversation):
        question = self.begin_signal + "human: " + conversation[0]['value'] + self.end_signal
        answer = self.begin_signal + "assistant: " + conversation[1]['value'] + self.end_signal
        combined_qa = question + answer

        tokenized_qa = self.tokenizer(combined_qa, padding="max_length", truncation=True,
                                      max_length=VLM_MAX_LENGTH, return_tensors="pt")
        input_ids = tokenized_qa.input_ids[0]
        label = input_ids.clone()
        pad_mask = tokenized_qa.input_ids[0] == self.tokenizer.pad_token_id
        label[pad_mask] = self.ignore_idx
        return input_ids, label

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        meta = self.data[idx]
        image_id = meta['image']
        image = Image.open(os.path.join(self.img_path, image_id)).convert('RGB')
        image = self.transform(image)
        input_id, label = self.preprocess(meta['conversation'])
        return dict(image=image, input_ids=input_id, label=label)

# Vision Encoder
class VisionEncoder(nn.Module):
    def __init__(self, hidden_dim=HIDDEN_SIZE):
        super().__init__()
        self.resnet = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
        self.resnet.fc = nn.Linear(self.resnet.fc.in_features, hidden_dim)

    def forward(self, images):
        return self.resnet(images)

# Vision-Language Model
class VisionLanguageModel(nn.Module):
    def __init__(self, hidden_dim=HIDDEN_SIZE):
        super().__init__()
        self.vision_encoder = VisionEncoder(hidden_dim)
        self.language_decoder = GPT2LMHeadModel.from_pretrained('gpt2')
        self.language_decoder.resize_token_embeddings(self.language_decoder.config.vocab_size + 1)
        self.projection = nn.Linear(hidden_dim, self.language_decoder.config.n_embd)

    def forward(self, images, input_ids, labels):
        vision_features = self.vision_encoder(images)  # [batch, hidden_dim]
        vision_features = self.projection(vision_features).unsqueeze(1)

        # Append <IMG> token embeddings to input
        inputs_embeds = self.language_decoder.transformer.wte(input_ids)
        inputs_embeds[:, 0, :] = vision_features.squeeze(1)  # Replace the first token with vision features
        outputs = self.language_decoder(inputs_embeds=inputs_embeds, labels=labels)
        return outputs.loss, outputs.logits

# Training Function
def train_vlm(json_path, image_folder_path):
    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.add_tokens(IMG_PATCH, special_tokens=True)

    train_dataset = LLaVADataset(json_path, image_folder_path, tokenizer, is_train=True)
    train_loader = DataLoader(train_dataset, batch_size=VL_BATCH_SIZE, shuffle=True)

    model = VisionLanguageModel().to(DEVICE)
    optimizer = AdamW(model.parameters(), lr=1e-5, weight_decay=0.1)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=50, num_training_steps=len(train_loader) * NUM_EPOCHS)

    model.train()
    for epoch in range(NUM_EPOCHS):
        total_loss = 0
        for batch in train_loader:
            images = batch['image'].to(DEVICE)
            input_ids = batch['input_ids'].to(DEVICE)
            labels = batch['label'].to(DEVICE)
            
            optimizer.zero_grad()
            loss, _ = model(images, input_ids, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()

            total_loss += loss.item()
        print(f"Epoch {epoch+1}, Loss: {total_loss / len(train_loader)}")

    return model, tokenizer

# Save Logits for Evaluation
def save_logits(model, json_path, image_folder_path, tokenizer, filename):
    model.eval()
    test_dataset = LLaVADataset(json_path, image_folder_path, tokenizer, is_train=False)
    test_loader = DataLoader(test_dataset, batch_size=VL_BATCH_SIZE, shuffle=False)

    logits_list = []
    with torch.no_grad():
        for batch in test_loader:
            images = batch['image'].to(DEVICE)
            input_ids = batch['input_ids'].to(DEVICE)
            _, logits = model(images, input_ids, labels=None)
            logits = logits[:, :VLM_MAX_LENGTH, :50257]  # Ensure proper shape
            logits_list.append(logits.cpu().numpy())

    logits = np.concatenate(logits_list, axis=0)
    np.save(filename, logits)

# Main Execution
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--json_path', type=str, required=True, help="Path to the instruction JSON file")
    parser.add_argument('--image_folder_path', type=str, required=True, help="Path to the image folder")
    args = parser.parse_args()

    model, tokenizer = train_vlm(args.json_path, args.image_folder_path)
    save_logits(model, args.json_path, args.image_folder_path, tokenizer, '20233960.npy')
