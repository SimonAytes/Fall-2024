from builtins import range
import numpy as np
from random import shuffle
from past.builtins import xrange


def svm_loss_naive(W, X, y, reg):
    """
    Structured SVM loss function, naive implementation (with loops).

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
      that X[i] has label c, where 0 <= c < C.
    - reg: (float) regularization strength

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
    """
    dW = np.zeros(W.shape)  # initialize the gradient as zero

    # Get the dimensions
    num_classes = W.shape[1]
    num_train = X.shape[0]

    # Initialize the loss
    loss = 0.0

    # Compute loss and gradient using explicit loops
    for i in range(num_train):
        scores = X[i].dot(W)  # Compute scores for all classes
        correct_class_score = scores[y[i]]  # Score of the correct class
        for j in range(num_classes):
            if j == y[i]:
                continue  # Skip the correct class

            margin = scores[j] - correct_class_score + 1  # delta = 1
            if margin > 0:
                loss += margin

                # Compute gradient: accumulate dW for incorrect and correct class
                dW[:, j] += X[i]  # Gradient for incorrect class
                dW[:, y[i]] -= X[i]  # Gradient for correct class

    # Average the loss and gradient over the batch
    loss /= num_train
    dW /= num_train

    #############################################################################
    # TODO:                                                                     #
    # Compute the gradient of the loss function and store it dW.                #
    # Rather that first computing the loss and then computing the derivative,   #
    # it may be simpler to compute the derivative at the same time that the     #
    # loss is being computed. As a result you may need to modify some of the    #
    # code above to compute the gradient.                                       #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # Add regularization to the loss and gradient
    loss += reg * np.sum(W * W)
    dW += 2 * reg * W

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW


def svm_loss_vectorized(W, X, y, reg):
    """
    Structured SVM loss function, vectorized implementation.

    Inputs and outputs are the same as svm_loss_naive.
    """
    loss = 0.0
    dW = np.zeros(W.shape)  # initialize the gradient as zero

    #############################################################################
    # TODO:                                                                     #
    # Implement a vectorized version of the structured SVM loss, storing the    #
    # result in loss.                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # Get the number of training examples
    N = X.shape[0]

    # Compute the scores for all classes
    scores = X.dot(W)  # Shape: (N, C)

    # Select the correct class scores for each example
    correct_class_scores = scores[np.arange(N), y].reshape(-1, 1)  # Shape: (N, 1)

    # Compute the margins: max(0, scores - correct_class_score + 1)
    margins = np.maximum(0, scores - correct_class_scores + 1)  # Shape: (N, C)
    margins[np.arange(N), y] = 0  # Do not consider correct class in the loss

    # Compute the loss
    loss = np.sum(margins) / N  # Average over the batch
    loss += reg * np.sum(W * W)  # Add regularization to the loss

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    #############################################################################
    # TODO:                                                                     #
    # Implement a vectorized version of the gradient for the structured SVM     #
    # loss, storing the result in dW.                                           #
    #                                                                           #
    # Hint: Instead of computing the gradient from scratch, it may be easier    #
    # to reuse some of the intermediate values that you used to compute the     #
    # loss.                                                                     #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # Compute the gradient
    binary = margins > 0  # Binary mask where margin > 0
    row_sum = np.sum(binary, axis=1)  # Sum of positive margins for each example
    binary[np.arange(N), y] = -row_sum  # Correct class gradient adjustment

    dW = X.T.dot(binary) / N  # Average over the batch
    dW += 2 * reg * W  # Add regularization to the gradient

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW
