from builtins import range
import numpy as np
from random import shuffle
from past.builtins import xrange


def softmax_loss_naive(W, X, y, reg):
    """
    Softmax loss function, naive implementation (with loops)

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
      that X[i] has label c, where 0 <= c < C.
    - reg: (float) regularization strength

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using explicit loops.     #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    
    # Get dimensions
    N = X.shape[0]  # Number of samples
    D, C = W.shape  # Dimensions of the weight matrix

    # Compute the softmax loss and gradient using explicit loops
    for i in range(N):  # Loop over each example
        scores = X[i].dot(W)  # Compute scores for each class
        scores -= np.max(scores)  # Avoid numerical instability

        # Compute softmax probabilities
        exp_scores = np.exp(scores)
        probs = exp_scores / np.sum(exp_scores)

        # Compute the loss for the correct class
        correct_class_prob = probs[y[i]]
        loss += -np.log(correct_class_prob)

        # Compute gradient dW
        for j in range(C):  # Loop over each class
            if j == y[i]:
                dW[:, j] += (probs[j] - 1) * X[i]
            else:
                dW[:, j] += probs[j] * X[i]

    # Average the loss and add regularization
    loss /= N
    loss += 0.5 * reg * np.sum(W * W)  # L2 regularization

    # Average the gradient and add regularization gradient
    dW /= N
    dW += reg * W

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax loss function, vectorized version.

    Inputs and outputs are the same as softmax_loss_naive.
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    # Get dimensions
    N = X.shape[0]  # Number of samples

    # Compute the class scores and apply numerical stability fix
    scores = X.dot(W)  # Shape: (N, C)
    scores -= np.max(scores, axis=1, keepdims=True)  # Avoid numerical instability

    # Compute the softmax probabilities
    exp_scores = np.exp(scores)  # Shape: (N, C)
    probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)  # Shape: (N, C)

    # Compute the loss
    correct_logprobs = -np.log(probs[np.arange(N), y])
    loss = np.sum(correct_logprobs) / N
    loss += 0.5 * reg * np.sum(W * W)  # Add regularization to the loss

    # Compute the gradient
    dprobs = probs  # Shape: (N, C)
    dprobs[np.arange(N), y] -= 1  # Subtract 1 for the correct class
    dprobs /= N  # Average over the batch

    dW = X.T.dot(dprobs)  # Shape: (D, C)
    dW += reg * W  # Add regularization to the gradient

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW
