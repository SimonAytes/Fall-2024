import os
import random
import argparse  # New import for handling command line arguments
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, WeightedRandomSampler
from torch.amp import autocast, GradScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    precision_recall_curve, roc_auc_score, f1_score, classification_report, auc
)
from tqdm import tqdm
from PIL import Image
from albumentations import (
    Compose, CLAHE, GaussianBlur, CenterCrop, Normalize, RandomRotate90, RandomBrightnessContrast
)
from albumentations.pytorch.transforms import ToTensorV2

# Ensure optimal algorithm selection
torch.backends.cudnn.benchmark = True

# Directory for saving checkpoints
CHECKPOINT_DIR = "/root/simon/checkpoints/"
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Custom normalization values
custom_mean = [0.5058] * 3
custom_std = [0.2508] * 3

# Augmentations for training and validation datasets
train_transforms = Compose([
    CenterCrop(192, 192),
    CLAHE(),
    GaussianBlur(blur_limit=(3, 7), p=0.5),
    RandomRotate90(p=0.5),
    RandomBrightnessContrast(p=0.5),
    Normalize(mean=custom_mean, std=custom_std),
    ToTensorV2()
])

val_transforms = Compose([
    CenterCrop(192, 192),
    Normalize(mean=custom_mean, std=custom_std),
    ToTensorV2()
])

# MixUp Augmentation
class MixUp:
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def __call__(self, image, label, dataset):
        lam = np.random.beta(self.alpha, self.alpha)
        index = random.randint(0, len(dataset) - 1)
        image2, label2 = dataset[index]
        mixed_image = lam * image + (1 - lam) * image2
        mixed_label = lam * label + (1 - lam) * label2
        return mixed_image, mixed_label

# Dataset class
class NIHCXR_Dataset(torch.utils.data.Dataset):
    def __init__(self, df, transforms=None, use_mixup=False):
        self.df = df.reset_index(drop=True)
        self.transforms = transforms
        self.use_mixup = use_mixup

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(row['img_path']).convert('RGB').resize((224, 224))
        image = np.array(image)
        label = row['nodule']  # Keep label as is (float-compatible)

        if self.transforms:
            image = self.transforms(image=image)["image"]

        if self.use_mixup and random.random() < 0.5:
            image, label = MixUp()(image, label, self)

        label = torch.tensor(label, dtype=torch.float32)  # Ensure float type
        return image, label

# Parse command line arguments
parser = argparse.ArgumentParser(description='Train a model on the NIH-CXR dataset.')
parser.add_argument('--train_csv_path', type=str, default='/root/simon/train.csv', 
                    help='Path to the training CSV file.')
parser.add_argument('--trainset_path', type=str, default='/root/simon/nih-cxr-resized512/', 
                    help='Path to the image dataset.')

args = parser.parse_args()
train_csv_path = args.train_csv_path
trainset_path = args.trainset_path

# Load and split data
df = pd.read_csv(train_csv_path)
df['img_path'] = df['img_path'].apply(lambda x: f"{trainset_path}{x}")

train_df, val_df = train_test_split(df, test_size=0.2, stratify=df['nodule'], random_state=42)

# Weighted sampling to handle class imbalance
class_counts = train_df['nodule'].value_counts().to_dict()
class_weights = {cls: len(train_df) / count for cls, count in class_counts.items()}
sample_weights = train_df['nodule'].map(class_weights).values

sampler = WeightedRandomSampler(sample_weights, num_samples=len(sample_weights), replacement=True)

train_dataset = NIHCXR_Dataset(train_df, transforms=train_transforms, use_mixup=True)
val_dataset = NIHCXR_Dataset(val_df, transforms=val_transforms)

train_loader = DataLoader(train_dataset, batch_size=8, sampler=sampler, num_workers=2, pin_memory=True)
val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False, num_workers=2, pin_memory=True)

# Model setup
from vit import vit_small, SimpleWrapper, CLSHead, DINOHead

vit_backbone = vit_small(patch_size=6)
cls_head = CLSHead(in_dim=384, hidden_dim=256, num_classes=1)
dino_head = DINOHead(in_dim=384)

model = SimpleWrapper(backbone=vit_backbone, head=dino_head, cls_head=cls_head).to(device)

# Initialize weights with Xavier initialization
def initialize_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)

model.apply(initialize_weights)

# Freeze layers for the initial training phase
for name, param in model.backbone.named_parameters():
    param.requires_grad = False

# Focal Loss for better class imbalance handling
class FocalLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, inputs, targets):
        BCE_loss = nn.functional.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        pt = torch.exp(-BCE_loss)
        loss = self.alpha * (1 - pt) ** self.gamma * BCE_loss
        return loss.mean()

loss_fn = FocalLoss()

# Gradient scaler for mixed precision
scaler = GradScaler()

# Checkpoint function
def save_checkpoint(epoch, model, optimizer, best_auc, path):
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_auc': best_auc
    }
    torch.save(checkpoint, path)
# Initialize optimizer and scheduler before training starts
def create_optimizer(model, lr=1e-5, weight_decay=1e-4):
    return optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

# Modified train_model function to accept optimizer and scheduler as arguments
def train_model(optimizer, scheduler, epochs, fine_tuning=False, patience=4):
    global best_auc, trigger_times
    best_auc, trigger_times = 0.0, 0  # Reset at the start

    for epoch in range(epochs):
        model.train()
        all_preds, all_labels = [], []
        epoch_loss = 0.0

        phase = "Fine-tuning" if fine_tuning else "Training"
        loop = tqdm(train_loader, desc=f"{phase} Epoch [{epoch+1}/{epochs}]")

        for images, labels in loop:
            images, labels = images.to(device), labels.to(device).float()
            optimizer.zero_grad(set_to_none=True)

            with autocast(device_type='cuda'):
                outputs = model(images)
                loss = loss_fn(outputs, labels.unsqueeze(1))

            scaler.scale(loss).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()

            epoch_loss += loss.item()

            preds = (torch.sigmoid(outputs).detach().cpu().numpy() >= 0.5).astype(int)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy().astype(int))

        train_f1 = f1_score(all_labels, all_preds)
        print(f"{phase} Epoch {epoch+1} - Train F1: {train_f1:.4f}, Loss: {epoch_loss / len(train_loader):.4f}")

        # Validation Phase
        model.eval()
        val_probs, val_labels = [], []

        with torch.no_grad():
            for images, labels in val_loader:
                images = images.to(device)
                outputs = model(images)

                probs = torch.sigmoid(outputs).cpu().numpy().flatten()
                preds = (probs >= 0.5).astype(int)

                val_probs.extend(probs)
                val_labels.extend(labels.numpy().astype(int))

        val_f1 = f1_score(val_labels, preds)
        roc_auc = roc_auc_score(val_labels, val_probs)
        print(f"Val F1: {val_f1:.4f}, ROC-AUC: {roc_auc:.4f}")

        if epoch > 1 and scheduler:
            scheduler.step(roc_auc)

        save_checkpoint(epoch, model, optimizer, roc_auc, f"{CHECKPOINT_DIR}/checkpoint_epoch_{epoch+1}.pth")

        if roc_auc > best_auc:
            best_auc = roc_auc
            trigger_times = 0
            print(f"New best model saved with ROC-AUC: {best_auc:.4f}")
        else:
            trigger_times += 1
            print(f"Trigger times: {trigger_times}/{patience}")
            if trigger_times >= patience:
                print("Early stopping.")
                return

# Initialize and run the training
print("Starting Regular Training...")
optimizer = create_optimizer(model)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.5, patience=3, verbose=True)

train_model(optimizer, scheduler, epochs=8)

# Unfreeze all layers for fine-tuning
for param in model.backbone.parameters():
    param.requires_grad = True

print("Starting Fine-Tuning...")
optimizer = create_optimizer(model, lr=1e-6)  # Lower learning rate for fine-tuning
train_model(optimizer, scheduler, epochs=5, fine_tuning=True)

print("Training complete.")