import pandas as pd
import torch
from PIL import Image
import numpy as np
from albumentations import (
    Compose, CenterCrop, Normalize
)
from albumentations.pytorch.transforms import ToTensorV2
from pathlib import Path
from vit import vit_small, SimpleWrapper, CLSHead, DINOHead

# Ensure optimal algorithm selection
torch.backends.cudnn.benchmark = True

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Custom normalization values
custom_mean = [0.5058] * 3
custom_std = [0.2508] * 3

# Image transformations (same as used in validation)
transforms = Compose([
    CenterCrop(192, 192),
    Normalize(mean=custom_mean, std=custom_std),
    ToTensorV2()
])

from vit import vit_small, SimpleWrapper, CLSHead, DINOHead


# Load the model from a checkpoint
def load_model(checkpoint_path):
    vit_backbone = vit_small(patch_size=6)
    cls_head = CLSHead(in_dim=384, hidden_dim=256, num_classes=1)
    dino_head = DINOHead(in_dim=384)
    model = SimpleWrapper(backbone=vit_backbone, head=dino_head, cls_head=cls_head).to(device)

    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()  # Set model to evaluation mode

    return model

# Load the checkpoint
model = load_model("/root/simon/checkpoints/best_model.pth")

# Preprocess a single image
def preprocess_image(image_path):
    image = Image.open(image_path).convert('RGB').resize((224, 224))
    image = np.array(image)
    transformed = transforms(image=image)["image"]
    return transformed.unsqueeze(0).to(device)  # Add batch dimension

# Predict on a single image
def predict_image(image_path):
    image_tensor = preprocess_image(image_path)
    with torch.no_grad():
        with torch.amp.autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
            output = model(image_tensor)
            prob = torch.sigmoid(output).item()  # Get the probability

    # Classify based on the optimal threshold
    prediction = 1 if prob >= 0.10 else 0
    return prediction, prob

# Main function to classify all images from a CSV file
def classify_images(input_csv, output_csv, testset_path):
    # Load the input CSV
    df = pd.read_csv(input_csv)

    # Ensure the 'img_path' column exists
    if 'ID' not in df.columns:
        raise ValueError("Input CSV must contain an 'ID' column with image identifiers.")

    # Prepare a list to store predictions
    results = []

    # Loop through each image path and make predictions
    testset_path = Path(testset_path)  # Convert to Path object
    for _, row in df.iterrows():
        image_path = testset_path / f"{row['ID']}.jpg"

        # Check if the image exists
        if not image_path.exists():
            print(f"Warning: {image_path} does not exist. Skipping.")
            continue

        # Make prediction
        prediction, prob = predict_image(image_path)

        results.append({
            'ID': row['ID'],  # Save the ID, not the full path
            'nodule': prediction,
        })

    # Save the results to the output CSV
    results_df = pd.DataFrame(results)
    results_df.to_csv(output_csv, index=False)
    print(f"Classification results saved to {output_csv}")

# Example usage
if __name__ == "__main__":
    input_csv = "/root/simon/test.csv"  # Adjust the path as necessary
    output_csv = "/root/simon/best_model_results.csv"
    testset_path = "/root/simon/test/test"
    classify_images(input_csv, output_csv, testset_path)
